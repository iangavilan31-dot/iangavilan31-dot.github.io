POCKET GODS — Windows playable prototype

Launch POCKET-GODS.exe. No Godot installation is needed.
Windows x64 and a compatible Forward+ graphics device are required.

WASD move, mouse aim, Space rise, Ctrl descend, Shift boost, X brake.
Left mouse fires plasma; right mouse fires a sustained beam.
E interacts, Esc pauses, U opens upgrades, P toggles photo mode.
Flight key bindings can be changed in Suit settings.

The solo expedition includes three small planets and the Stillwater Rift.
Two-player host/join uses UDP 5188. LAN play needs the host's address;
Internet play requires a reachable host and is not relay-assisted.

This is a playable prototype. Visual development remains in progress.
Mac, physical controller and public-Internet co-op testing are not complete.

Keep the licenses folder with this game when sharing it.
