# Asset and engine notices

## Original project content

The gameplay code, procedural planet and suit geometry, plants, creatures, effects, custom HUD glyphs, and synthesized WAV effects/music were created for POCKET GODS. The Bloomhaven grass albedo at `godot/assets/textures/bloomhaven_meadow_albedo.png` was generated for this project from a written prompt; the user-supplied reference guided the palette and painterly direction but is not used as a source image or texture. No downloaded model packs, commercial sound libraries, sampled songs, or proprietary character designs are bundled. Audio provenance and regeneration instructions are in [NETWORK.md](NETWORK.md) and `godot/assets/audio/audio_manifest.json`.

This notice does not assign a new license to the user's original project. It records the origin of bundled work and required third-party notices.

The user-supplied reference image is stored under `docs/visual-reference.png` for art direction. It is outside the Godot export directory and is not used as an in-game asset. Its reuse rights are not represented as part of this source's original content.

## Fonts

| Font | Source | License file |
|---|---|---|
| Lilita One — Juan Montoreano | [Google Fonts source](https://github.com/google/fonts/tree/main/ofl/lilitaone) | `godot/assets/fonts/LilitaOne-OFL.txt` |
| Outfit — Outfit project contributors | [Google Fonts source](https://github.com/google/fonts/tree/main/ofl/outfit) | `godot/assets/fonts/Outfit-OFL.txt` |

Both fonts use the SIL Open Font License 1.1. Binaries are bundled locally and are unmodified. The UI sets a variable-font axis at runtime; it does not rewrite the font binary. License files must remain with redistributed font files and are included in the release packaging instructions.

## Godot Engine

This game uses [Godot Engine](https://godotengine.org/), available under the [MIT license](https://godotengine.org/license/). Its exact 4.7.1 license is bundled as [GODOT-MIT.txt](licenses/GODOT-MIT.txt). Godot's third-party component notices are bundled as [GODOT-THIRD-PARTY.txt](licenses/GODOT-THIRD-PARTY.txt), obtained from the official `4.7.1-stable` source tag.

Keep both files and the font OFL texts alongside exported desktop distributions. The README's export instructions create a companion `licenses` directory. See [Godot's distribution notice guidance](https://docs.godotengine.org/en/stable/about/complying_with_licenses.html).

## Preserved browser draft

The root-level browser draft and its npm dependencies are separate from the native game's export. Its `package.json`/lockfile record those dependencies. Their own license files remain under the installed packages; they are not shipped inside the Godot game. If the browser draft is distributed separately, include its dependency notices as well.
